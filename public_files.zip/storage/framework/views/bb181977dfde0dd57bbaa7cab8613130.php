<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm sticky-top lms-header py-3">
  <div class="container-fluid px-4">
    <?php
      $brandLogoDiskPath = public_path('images/lms/logo.png');
      $brandLogoVersion = file_exists($brandLogoDiskPath) ? filemtime($brandLogoDiskPath) : null;
      $brandLogoUrl = $brandLogoVersion ? (asset('images/lms/logo.png') . '?v=' . $brandLogoVersion) : null;
    ?>

    <a class="navbar-brand d-flex align-items-center gap-2" href="/">
      <?php if($brandLogoUrl): ?>
        <img src="<?php echo e($brandLogoUrl); ?>" alt="Logo" width="28" height="28" class="rounded" style="object-fit: cover;">
      <?php endif; ?>
      <span><?php echo e(config('app.name', 'LMS')); ?></span>
    </a>
    
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav me-auto">
        
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('courses.index')); ?>">Courses</a>
        </li>
      </ul>
      
      <ul class="navbar-nav ms-auto" id="auth-links">
        
        
        <li class="nav-item logged-out-only">
          <a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a>
        </li>
        <li class="nav-item logged-out-only">
          <a class="nav-link" href="<?php echo e(route('register')); ?>">Register</a>
        </li>
        
        
        <li class="nav-item logged-in-only" style="display: none;">
          <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
        </li>

        
        <li class="nav-item logged-in-only" style="display: none;">
            <button class="btn btn-sm btn-outline-light" onclick="logout()">Logout</button>
        </li>
      </ul>
    </div>
  </div>
</nav><?php /**PATH C:\xampp\htdocs\lmsfinalproject\resources\views/includes/navbar.blade.php ENDPATH**/ ?>