

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-10">
        <div class="card shadow-lg">
            <div class="card-header bg-secondary text-white">
                <h3 class="mb-0">Redirecting...</h3>
            </div>
            <div class="card-body p-4">
                <p class="text-muted mb-0">Taking you to your dashboard based on your role...</p>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const user = getUserData();
        const token = getAuthToken();

        if (!token || !user || !user.role) {
            window.location.href = '/login';
            return;
        }

        if (user.role === 'admin') {
            window.location.href = '/admin/dashboard';
        } else if (user.role === 'teacher') {
            window.location.href = '/teacher/dashboard';
        } else {
            window.location.href = '/student/dashboard';
        }
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\USER 1\OneDrive\Desktop\AyyanLaravel\lmsfinalproject\resources\views/dashboard.blade.php ENDPATH**/ ?>